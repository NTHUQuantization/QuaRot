"""Read-only progress; does not contact the GPU or alter measurements."""
import json
from pathlib import Path

root=Path(__file__).resolve().parent
workspace=root.parent.parent
preparation=workspace/'gptq_preflight_20260925/status.json'
if preparation.exists():
    print('GPTQ preparation:',json.loads(preparation.read_text()))
    for size,layers in [('8b',36),('14b',40),('32b',64)]:
        checkpoint=workspace/f'qwen3_{size}_fused_v1_gptq_w4a4kv4_v1'
        count=len(list(checkpoint.glob('model-layer-*.safetensors')))
        print(f'{size}: {count}/{layers} layer shards; finalized config={(checkpoint/"config.json").exists()}')
for name in ('queue_status.json','progress.json','publication_receipts.json'):
    path=root/name
    if path.exists():
        print(name)
        print(json.dumps(json.loads(path.read_text()),ensure_ascii=False,indent=2))
for stage in ('pilot','formal'):
    for v in 'ABCDE':
        folder=root/'results'/stage/v
        records=folder/'runs.jsonl'
        n=len(records.read_text().splitlines()) if records.exists() else 0
        status='complete' if (folder/'complete.json').exists() else ('running/partial' if n else 'pending')
        print(f'{stage:6s} {v}: {n:4d}/{108 if stage=="pilot" else 864} {status}')
