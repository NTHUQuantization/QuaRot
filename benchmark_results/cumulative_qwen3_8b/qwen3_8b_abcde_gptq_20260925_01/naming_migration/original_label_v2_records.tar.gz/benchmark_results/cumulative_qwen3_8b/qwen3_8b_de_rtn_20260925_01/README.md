# 歷史正式結果：8B RTN D／E

狀態：已完成且驗證通過的歷史正式測量；不是 GPTQ。D=Fused AR（原 C），E=PARD2-TI（原 D）。

[正式報告](formal/report_zh.md)；[原始資料](formal/runs.jsonl)。

96 題、每題 3 次、prefill/decode/E2E，共 1728 筆；D/E 等輸出。新增分位數由原始時間重算，舊測量沒有 peak memory，保持缺值。

provenance/relabel_manifest.json 保存改標對照；原始舊代號產物仍保留於 fused_v1/ablation_qwen3_8b_cd_20260925_01，沒有覆寫。此資料不併入新 GPTQ 主表。
