> 已依修正版代號重新標示：D=Fused AR（原 C），E=PARD2-TI（原 D）。此為歷史測量的無損改標；peak memory 尚未測得。

# Qwen3-8B D／E formal 測量

資格：通過 D／E 同輸出驗證。
共 96 題；每題每 phase 3 次；batch=1；自然 EOS；thinking 關閉；輸出上限 256 tokens。
D：融合 INT4 AR；E：相同 target + PARD2-TI，BF16 draft，k=15，無 adaptive-k／AR fallback。
E2E 是本地生成時間，不含載入、tokenizer、網路、輸出比對。先對 repeats 取 median，再對 prompts 取 median。

|資料集|版本|Prefill ms|Decode ms|E2E ms|Decode tokens/s|E2E tokens/s|cap 比例|
|---|---|---:|---:|---:|---:|---:|---:|
|humaneval|D|69.067|4585.750|4643.649|55.787|55.089|0.844|
|humaneval|E|126.025|2434.390|2550.886|104.241|99.358|0.844|
|gsm8k|D|61.768|4514.829|4556.805|56.303|55.668|0.500|
|gsm8k|E|99.289|2051.550|2134.989|100.116|97.093|0.500|
|math_500|D|60.107|4543.668|4589.789|56.342|55.776|0.875|
|math_500|E|92.902|2082.171|2152.693|121.274|117.076|0.875|

|資料集|D→E E2E 配對幾何平均|95% bootstrap CI|
|---|---:|---:|
|humaneval|1.826×|1.680–1.980|
|gsm8k|1.742×|1.631–1.861|
|math_500|2.067×|1.939–2.194|
|overall_equal_dataset|1.874×|1.798–1.947|

跨版本輸出完全相同：96/96；完整量測：96/96。
A／B／C 未在此歷史測量範圍內，故不報相對 A 加速，也不宣稱完成五版本消融。
本次單次載入每版本後完成 3 sweeps；GPU 時脈／溫度／process 狀態見 gpu.jsonl。
不一致樣本全部保留於 cross_variant_qualification.jsonl；未刪除或以成功交集替代。

D 成本（秒）：`{"load_seconds": 43.58748262748122, "warmup_seconds": 29.02809375245124, "measurement_wall_seconds": 2559.1930700894445, "process_work_seconds": 2632.145338143222, "records": 864, "completed_unix": 1790321211.8118627}`

E 成本（秒）：`{"load_seconds": 44.61060815304518, "warmup_seconds": 23.581985746510327, "measurement_wall_seconds": 1428.0602587452158, "process_work_seconds": 1497.4861392611638, "records": 864, "completed_unix": 1790322714.0905066}`

本次是「256-token 輸出預算下的生成效能」，碰到 cap 不代表答案完成或答對。

Pilot 與完整歷史檔案見原始結果目錄（原始代號 C／D，對应現在 D／E），與正式統計分開；原始正式資料見 [runs.jsonl](runs.jsonl)。

來源／設定補充：

- D／E 使用同一組 checkpoint 檔案，已在測量前後核對 SHA256；沒有重新量化或更換權重。
- 此既有 8B checkpoint 為 legacy_hadk 格式；依載入程式與 config，activation clip ratio=1.0；不是 grouped_h256_v1／clip 0.9 的 32B 格式。checkpoint 未附完整原始量化製作 provenance，故以檔案 hash 固定本次 D／E 比較，不宣稱已證明 A／B 的數值來源一致。
- 實際 flags：fused projections、fused norm quant、fused decode append、native GQA、exact row norm 啟用；attention fused-K1 未啟用。完整 source／extension／dirty 狀態見 variant_manifest.json。
- 沒有改變 GPU 功耗／時脈政策；每 request 前保存 GPU 狀態。版本以 D→E 單次載入執行，存在時間順序造成的溫度／時脈漂移限制。
- 首次正式 D 在 18 筆後因 CPU-only 測試程序被監控誤判為 GPU 競爭而停止；已完整封存並重跑正式 D。修正僅影響計時外的監控與續跑控制，舊 manifest、程式版本與中斷資料都保留。
- Phase 契約 CPU 測試 3 項通過：完整 prefill 邊界、EOS 位於接受 chunk 中間、上限位於 chunk 中間與下一輪 bonus token；正式 96 題另作實際 D AR oracle 比對。

|資料集|Input tokens：min／median／max|Output tokens：min／median／max|
|---|---:|---:|
|humaneval|76／155.5／419|168／256／256|
|gsm8k|49／79.5／131|93／254.5／256|
|math_500|35／68／197|169／256／256|

從 manifest 建立至最終稽核完成的實際 wall time（含 pilot、載入、暖機、中斷重跑及稽核）：81.1 分鐘。各版本獨立成本列於上方。
