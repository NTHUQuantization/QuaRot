# 已被 GPTQ 要求取代的 RTN pilot

A/B 各完成 12 題、3 sweeps、3 phases，共各 108 筆。這些是 pilot，不是正式結果。原計畫在使用者要求 GPTQ 後停止；沒有以此發布正式 A–E 表格。
