# Qwen3-8B 消融結果總入口

所有報表使用 A=main、B=GEMM、C=Hadacore、D=Fused AR、E=PARD2-TI。舊 C/D 已明確對應為新 D/E；RTN 與 GPTQ 分開，不混算。

|資料|權重|範圍|位置|
|---|---|---|---|
|歷史正式結果|RTN|D/E，96 題、1728 筆，已驗證|[正式報告](qwen3_8b_de_rtn_20260925_01/formal/report_zh.md)|
|新一輪正式結果|GPTQ|A–E，待量化與完整測量驗證|完成後建立 `qwen3_8b_abcde_gptq_20260925_01/`|
|被取代的試跑|RTN|A/B pilot，非正式結果|[封存說明](archive/rtn_ab_pilot_superseded_20260925/README.md)|

最新完成狀態以 [index.json](index.json) 為準。新一輪只有驗證完成才複製到此結果入口；執行中檔案與日誌保留在 `benchmark_work/qwen3_8b_abcde_gptq_20260925_01/`，權重轉換進度在 `gptq_preflight_20260925/`。

新正式目錄統一包含 `formal/`（主報告、CSV、raw records）、`pilot/`（獨立試跑）、`checkpoint_audits/`、`runtime_source/`、`harness/` 與根目錄 manifests。Remote branches 使用相同 run_id 與目錄規格。
