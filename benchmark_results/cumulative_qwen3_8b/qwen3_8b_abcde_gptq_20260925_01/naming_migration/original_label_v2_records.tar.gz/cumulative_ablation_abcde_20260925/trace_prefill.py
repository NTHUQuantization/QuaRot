"""Untimed first-difference trace against the previously measured fused target."""
import json
from pathlib import Path
import sys
import torch
from runtime_adapter import ROOT, load, phases


@torch.inference_mode()
def main(variant):
    out=ROOT/'diagnostics'/variant
    runtime=load(variant,out)
    prompts=[json.loads(l) for l in (ROOT/'results_DE_previous/prompts.jsonl').read_text().splitlines()]
    p=next(p for p in prompts if p['stage']=='pilot')
    captures={}
    def hook(name):
        def capture(module, args, value):
            if isinstance(value,tuple): value=value[0]
            if hasattr(value,'quantized_x'):
                captures[name]={'packed':value.quantized_x.detach().cpu(),'scale':value.scales_x.detach().cpu()}
            else:
                captures[name]=value.detach().cpu()
        return capture
    selected={'model.embed_tokens','model.norm'}
    for i in (0,1,2,35):
        for name in ('self_attn.quantizer','self_attn','mlp.quantizer','mlp',''):
            selected.add(f'model.layers.{i}'+('.'+name if name else ''))
    handles=[m.register_forward_hook(hook(n)) for n,m in runtime.target.named_modules() if n in selected]
    adapter=phases(runtime,torch.tensor([p['input_ids']],device='cuda'),32)
    state=adapter.begin()
    captures['logits']=state.gi_frame.f_locals['output'].logits.detach().cpu()
    state.close()
    for h in handles:h.remove()
    torch.save(captures,out/'prefill_trace.pt')
    top=captures['logits'][0,-1].topk(10)
    print(variant,'top logits',list(zip(top.indices.tolist(),top.values.tolist())),flush=True)


if __name__=='__main__':main(sys.argv[1])
