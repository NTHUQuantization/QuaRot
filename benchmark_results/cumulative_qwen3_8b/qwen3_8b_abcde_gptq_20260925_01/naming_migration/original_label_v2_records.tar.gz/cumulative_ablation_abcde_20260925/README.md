# 已封存的 RTN 執行工作目錄

使用者已選定 A–E 全部共用 GPTQ 另開新一輪；此 RTN 佇列已停止且禁止重啟／發布。A/B 只完成 pilot，沒有新的 ABC 正式結果。

整理後的結果入口：[benchmark_results/cumulative_qwen3_8b](../benchmark_results/cumulative_qwen3_8b/README.md)。新 GPTQ 工作目錄：[benchmark_work/qwen3_8b_abcde_gptq_20260925_01](../benchmark_work/qwen3_8b_abcde_gptq_20260925_01/README.md)。

本目錄保留分支 checkout 與原始診斷，供 provenance 追查；它不是正式報表入口。
