"""Read-only progress; does not contact the GPU or alter measurements."""
import json
from pathlib import Path

root=Path(__file__).resolve().parent
for name in ('queue_status.json','progress.json','publication_receipts.json'):
    path=root/name
    if path.exists():
        print(name)
        print(json.dumps(json.loads(path.read_text()),ensure_ascii=False,indent=2))
for stage in ('pilot','formal'):
    for v in 'ABCDE':
        folder=root/'results'/stage/v
        records=folder/'runs.jsonl'
        n=len(records.read_text().splitlines()) if records.exists() else 0
        status='complete' if (folder/'complete.json').exists() else ('running/partial' if n else 'pending')
        print(f'{stage:6s} {v}: {n:4d}/{108 if stage=="pilot" else 864} {status}')
